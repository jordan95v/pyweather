class WeatherError(Exception):
    """Raised when there is an error with the client."""
